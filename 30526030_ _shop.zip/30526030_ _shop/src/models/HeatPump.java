package models;


import models.Product;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

public class HeatPump extends Product {
    private double efficiencyRating;

    public HeatPump() { super(); }

    public HeatPump(String productName, double price, int stockLevel, double efficiencyRating) {
        super(productName, price, stockLevel);
        this.efficiencyRating = efficiencyRating;
    }

    public HeatPump(int productId, String productName, double price, int stockLevel, double efficiencyRating) {
        super(productId, productName, price, stockLevel);
        this.efficiencyRating = efficiencyRating;
    }

    public double getEfficiencyRating() { return efficiencyRating; }
    // ... setters
}