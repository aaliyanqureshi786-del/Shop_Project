package models;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 
 */
public class Product {
    private int productId;
    private String productName;
    private double price;
    private int stockLevel;

    // Constructor 1: Default
    public Product() {}

    // Constructor 2: Everything EXCEPT ProductId
    public Product(String productName, double price, int stockLevel) {
        this.productName = productName;
        this.price = price;
        this.stockLevel = stockLevel;
    }

    // Constructor 3: Everything
    public Product(int productId, String productName, double price, int stockLevel) {
        this.productId = productId;
        this.productName = productName;
        this.price = price;
        this.stockLevel = stockLevel;
    }
    
    // Getters
    public double getPrice() { return price; }
    public String getProductName() { return productName; }
    public int getProductId() { return productId; }
    public int getStockLevel() { return stockLevel; }

    // Setters
    public void setProductId(int productId) { this.productId = productId; }
    public void setPrice(double price) { this.price = price; }

    // -------------------------------------------------------------------------
    // STAGE 6 REQUIREMENT: toString() Override
    // Following Animal_Explanation.docx: Tells the JList how to display the product.
    // -------------------------------------------------------------------------
    @Override
    public String toString() {
        // You can choose the format. Here we show Name and Price.
        return productName + " (£" + String.format("%.2f", price) + ")";
    }
}