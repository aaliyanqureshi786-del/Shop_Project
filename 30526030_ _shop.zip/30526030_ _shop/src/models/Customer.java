package models;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import java.util.HashMap;

public class Customer extends User {
    private String addressLine1;
    private String addressLine2;
    private String town;
    private String postcode;
    private boolean isRegistered;
    private HashMap<Integer, Order> orders; // Stage 3: HashMap of Orders

    // Constructor 1: Default (0 Parameters) 
    
    // Inside Customer.java
public String getTown() { 
    return town; 
}
    
    public Customer() {
        super();
        this.orders = new HashMap<>(); // Initialize map
    }

    // Constructor 2: Everything EXCEPT isRegistered (8 existing + 1 new = 9 parameters total) - MODIFIED for Stage 3
    public Customer(String username, String password, String firstName, String lastName,
                    String addressLine1, String addressLine2, String town, String postcode,
                    HashMap<Integer, Order> orders) { // 9th parameter
        super(username, password, firstName, lastName);
        this.addressLine1 = addressLine1;
        this.addressLine2 = addressLine2;
        this.town = town;
        this.postcode = postcode;
        this.isRegistered = false; // Excluded from params
        this.orders = orders; // Assign map
    }

    // Getters & Setters (only new/modified ones shown for brevity)
    public HashMap<Integer, Order> getOrders() { return orders; }
    public void setOrders(HashMap<Integer, Order> orders) { this.orders = orders; }
    public boolean getIsRegistered() { return isRegistered; }
    public void setIsRegistered(boolean isRegistered) { this.isRegistered = isRegistered; }
    // ... other getters/setters
}