package models;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * DBManager implementation for Stage 6.
 * Handles database connectivity and object instantiation for products, customers, and staff.
 */
public class DBManager {

    private static final String DB_PATH = "jdbc:ucanaccess://Data/ShopDB.accdb";

    /**
     * Helper method to establish database connection.
     */
    private Connection getConnection() throws SQLException {
        // For Ucanaccess, ensure the driver is available in the classpath.
        return DriverManager.getConnection(DB_PATH);
    }

    // -------------------------------------------------------------------------
    // Stage 5: LOGIN METHODS 
    // -------------------------------------------------------------------------
    
    /**
     * Validates customer credentials.
     */
    public Customer customerLogin(String username, String password) {
        ArrayList<Customer> allCustomers = loadCustomers(); 
        for (Customer c : allCustomers) {
            if (c.getUsername().equals(username) && c.getPassword().equals(password)) {
                return c; 
            }
        }
        return null; 
    }
    
    /**
     * Validates staff credentials.
     */
    public Staff staffLogin(String username, String password) {
        ArrayList<Staff> allStaff = loadStaff(); 
        for (Staff s : allStaff) {
            if (s.getUsername().equals(username) && s.getPassword().equals(password)) {
                return s; 
            }
        }
        return null; 
    }

    // -------------------------------------------------------------------------
    // Stage 6: LOAD PRODUCTS METHOD
    // -------------------------------------------------------------------------
    
    /**
     * Loads all products from the database and creates specific sub-type objects.
     * Uses the "Products" column as the category discriminator.
     */
    public ArrayList<Product> loadProducts() {
        ArrayList<Product> allProducts = new ArrayList<>();
        String sql = "SELECT * FROM Products";

        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                // Read base product details
                int id = rs.getInt("ProductID");
                String name = rs.getString("ProductName");
                double price = rs.getDouble("Price");
                int stock = rs.getInt("StockLevel");
                
                // Using "Products" as the column name for the category
                String category = rs.getString("ProductType");

                if (category.equals("Heat Pump")) {
                    // Read HeatPump specific data
                    double efficiency = rs.getDouble("EfficiencyRating");
                    HeatPump hp = new HeatPump(id, name, price, stock, efficiency);
                    allProducts.add(hp);
                } 
                else if (category.equals("Solar Panel")) {
                    // Read SolarPanel specific data
                    int wattage = rs.getInt("WattageOutput");
                    SolarPanel sp = new SolarPanel(id, name, price, stock, wattage);
                    allProducts.add(sp);
                }
            }
        } catch (SQLException e) {
            System.err.println("Database Error loading products: " + e.getMessage());
        }
        
        return allProducts;
    }

    // -------------------------------------------------------------------------
    // USER LOAD METHODS
    // -------------------------------------------------------------------------
    
    /**
     * Loads all customer records from the database.
     */
    public ArrayList<Customer> loadCustomers() {
        ArrayList<Customer> customers = new ArrayList<>();
        String sql = "SELECT * FROM Customers";

        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                // Initialize with an empty orders map for the constructor
                HashMap<Integer, Order> emptyOrders = new HashMap<>(); 

                Customer customer = new Customer(
                    rs.getString("Username"), rs.getString("Password"), 
                    rs.getString("FirstName"), rs.getString("LastName"),
                    rs.getString("AddressLine1"), rs.getString("AddressLine2"),
                    rs.getString("Town"), rs.getString("Postcode"),
                    emptyOrders 
                );

                customer.setIsRegistered(rs.getBoolean("IsRegistered"));
                customers.add(customer);
            }
        } catch (SQLException e) {
            System.err.println("Database Error loading customers: " + e.getMessage());
        }
        return customers;
    }

    /**
     * Loads all staff records from the database.
     */
    public ArrayList<Staff> loadStaff() {
        ArrayList<Staff> staffMembers = new ArrayList<>();
        String sql = "SELECT * FROM Staff";

        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Staff staff = new Staff(
                    rs.getString("Username"), rs.getString("Password"),
                    rs.getString("FirstName"), rs.getString("LastName"),
                    rs.getString("Position"), rs.getDouble("Salary")
                );
                staffMembers.add(staff);
            }
        } catch (SQLException e) {
            System.err.println("Database Error loading staff: " + e.getMessage());
        }
        return staffMembers;
    }
}