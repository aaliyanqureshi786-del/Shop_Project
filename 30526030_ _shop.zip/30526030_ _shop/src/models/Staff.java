package models;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

public class Staff extends User {
    private String position;
    private double salary;

    public Staff() { super(); }

    public Staff(String username, String password, String firstName, String lastName, 
                 String position, double salary) {
        super(username, password, firstName, lastName);
        this.position = position;
        this.salary = salary;
    }

    public String getPosition() { return position; }
    public double getSalary() { return salary; }
    // ... setters
}