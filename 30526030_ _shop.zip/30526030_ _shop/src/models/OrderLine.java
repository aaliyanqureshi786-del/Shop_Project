package models;


import models.Product;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

public class OrderLine {
    private int orderLineId;
    private Product product;
    private int quantity;
    private double lineTotal;

    public OrderLine(int id, Product p, int qty, double total) {
        this.orderLineId = id;
        this.product = p;
        this.quantity = qty;
        this.lineTotal = total;
    }

    public OrderLine(int id, Product p, int qty) {
        this.orderLineId = id;
        this.product = p;
        this.quantity = qty;
        this.lineTotal = p.getPrice() * qty; 
    }

    public int getOrderLineId() { return orderLineId; }
    public Product getProduct() { return product; }
    public int getQuantity() { return quantity; }
    public double getLineTotal() { return lineTotal; }
    // ... setters
}