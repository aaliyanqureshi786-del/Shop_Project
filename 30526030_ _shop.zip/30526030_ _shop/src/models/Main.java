package models;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

import models.Customer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Date;

public class Main {

    public static void main(String[] args) {

        System.out.println();
        
        // -------------------------------------------------------------------------
        // Setup: Products for Demonstration
        // -------------------------------------------------------------------------
        
        Product baseProduct = new Product(1, "Insulation Roll", 55.99, 100);
        Product productA = new Product(101, "Digital Thermostat", 125.00, 50); 
        Product productB = new Product(102, "LED Floodlight", 35.50, 200);

        // -------------------------------------------------------------------------
        // 1. Stage 1 Demonstration (User and Product)
        // -------------------------------------------------------------------------

        System.out.println("\n=======================");
        System.out.println("1. Stage 1: User & Product");
        System.out.println("=======================");
        
        User baseUser = new User("admin_01", "rootpass", "Alan", "Turing");
        System.out.println("User: " + baseUser.getFirstName() + " " + baseUser.getLastName());
        System.out.printf("Product: %s (Price: $%.2f)%n", 
            baseProduct.getProductName(), baseProduct.getPrice());

        // -------------------------------------------------------------------------
        // 2. Stage 2 Demonstration (Inheritance)
        // -------------------------------------------------------------------------

        System.out.println("\n=======================");
        System.out.println("2. Stage 2: Inheritance");
        System.out.println("=======================");

        // --- 2a. Customer Demonstration (Includes HashMap setup for Stage 3) ---
        HashMap<Integer, Order> customerOrders = new HashMap<>();
        
        // Customer (9-Parameter Constructor: 8 data + 1 HashMap)
        Customer cust = new Customer("jdoe", "secure123", "Jane", "Doe",
                                     "12 Main St", "Apt 2B", "Glasgow", "G1 1AA",
                                     customerOrders); 

        System.out.println("Customer: " + cust.getFirstName() + " " + cust.getLastName());
        System.out.println("Address: " + cust.getTown()); 
        
        // --- 2b. Staff Demonstration ---
        Staff manager = new Staff("pm_alex", "safePW", "Alex", "Brown", "Project Manager", 65000.00); 
        System.out.printf("Staff: %s (%s, Salary: $%.0f)%n", manager.getFirstName(), manager.getPosition(), manager.getSalary());

        // --- 2c. Product Subclasses Demonstration ---
        HeatPump modelA = new HeatPump(501, "EcoHeat 500", 3500.00, 10, 4.5);
        SolarPanel modelB = new SolarPanel("SunPower 400W", 250.00, 500, 400);

        System.out.println("HeatPump: " + modelA.getProductName() + " (Efficiency: " + modelA.getEfficiencyRating() + ")"); // This line now works
        System.out.println("SolarPanel: " + modelB.getProductName() + " (Wattage: " + modelB.getWattageOutput() + "W)"); // This line now works
        
        
        // -------------------------------------------------------------------------
        // 3. Stage 3 Demonstration (OrderLine and Order)
        // -------------------------------------------------------------------------

        System.out.println("\n=======================");
        System.out.println("3. Stage 3: Orders");
        System.out.println("=======================");
        
        // --- 3a. OrderLine Calculation Test ---
        OrderLine line1 = new OrderLine(1, productA, 3); // 375.00
        OrderLine line2 = new OrderLine(2, productB, 10); // 355.00
        
        System.out.printf("Line 1 Total: $%.2f%n", line1.getLineTotal());

        // --- 3b. Order Creation and Linking ---
        double orderTotal = line1.getLineTotal() + line2.getLineTotal(); 

        Order newOrder = new Order(1001, new Date(), orderTotal, "Shipped"); 
        
        newOrder.getOrderLines().put(line1.getOrderLineId(), line1);
        newOrder.getOrderLines().put(line2.getOrderLineId(), line2);
        
        System.out.println("Order ID: " + newOrder.getOrderId() + " (Total: $" + newOrder.getOrderTotal() + ")");
        
        // --- 3c. Link Order to Customer ---
        cust.getOrders().put(newOrder.getOrderId(), newOrder);
        
        System.out.println("Customer Orders Count: " + cust.getOrders().size());
        
        // =========================================================================
// PART 4: Demonstration of Stage 4 Database Manager
// =========================================================================

System.out.println("\n==================================");
System.out.println("4. Testing DBManager (Load Customers/Staff)");
System.out.println("==================================");

DBManager dbManager = new DBManager();

// --- Test Load Customers ---
ArrayList<Customer> loadedCustomers = dbManager.loadCustomers();

System.out.println("\n--- Loaded Customers ---");
System.out.println("Total Customers Loaded: " + loadedCustomers.size());

// Verify first loaded customer
if (!loadedCustomers.isEmpty()) {
    Customer firstCust = loadedCustomers.get(0);
    System.out.println("First Customer (Name): " + firstCust.getFirstName() + " " + firstCust.getLastName());
    System.out.println("First Customer (Town): " + firstCust.getTown());
    System.out.println("First Customer (Reg.): " + firstCust.getIsRegistered());
}


// --- Test Load Staff ---
ArrayList<Staff> loadedStaff = dbManager.loadStaff();

System.out.println("\n--- Loaded Staff ---");
System.out.println("Total Staff Loaded: " + loadedStaff.size());

// Verify first loaded staff member
if (!loadedStaff.isEmpty()) {
    Staff firstStaff = loadedStaff.get(0);
    System.out.println("First Staff (Name): " + firstStaff.getFirstName() + " " + firstStaff.getLastName());
    System.out.printf("First Staff (Salary): $%.2f%n", firstStaff.getSalary());
}
    }
}
