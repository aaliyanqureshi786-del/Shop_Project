package models;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import models.OrderLine;
import java.util.Date;
import java.util.HashMap;

public class Order {
    private int orderId;
    private Date orderDate;
    private double orderTotal;
    private String status;
    private HashMap<Integer, OrderLine> orderLines; 

    public Order() {
        this.orderDate = new Date();
        this.orderLines = new HashMap<>(); 
    }

    public Order(int id, Date date, double total, String status) {
        this.orderId = id;
        this.orderDate = date;
        this.orderTotal = total;
        this.status = status;
        this.orderLines = new HashMap<>();
    }

    public int getOrderId() { return orderId; }
    public double getOrderTotal() { return orderTotal; }
    public String getStatus() { return status; }
    public HashMap<Integer, OrderLine> getOrderLines() { return orderLines; }
    // ... other getters/setters
}